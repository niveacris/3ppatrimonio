<?php
/**
 * Plugin Name: 3P Patrimônio Leads Manager (Hostinger Ready)
 * Plugin URI: https://3ppatrimonio.com.br
 * Description: Plugin customizado para captação de leads e área de movimentação dos sócios no WordPress Hostinger.
 * Version: 1.0.1
 * Author: 3P Patrimônio & Consultoria
 * License: GPL2
 */

if (!defined('ABSPATH')) {
    exit; // Segurança contra acesso direto
}

// 1. Criação de tabela MySQL ao ativar o plugin no Hostinger
register_activation_hook(__FILE__, 'p3_create_leads_table');

function p3_create_leads_table() {
    global $wpdb;
    $table_name = $wpdb->prefix . 'p3_leads';
    $charset_collate = $wpdb->get_charset_collate();

    $sql = "CREATE TABLE $table_name (
        id bigint(20) NOT NULL AUTO_INCREMENT,
        created_at datetime DEFAULT CURRENT_TIMESTAMP NOT NULL,
        name varchar(255) NOT NULL,
        whatsapp varchar(50) NOT NULL,
        email varchar(100),
        objective varchar(150),
        credit_amount varchar(100),
        monthly_installment varchar(100),
        message text,
        status varchar(50) DEFAULT 'Novo',
        notes text,
        PRIMARY KEY  (id)
    ) $charset_collate;";

    require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
    dbDelta($sql);
}

// 2. Adiciona Menu "3P Patrimônio - Leads" no Painel WordPress
add_action('admin_menu', 'p3_register_admin_menu');

function p3_register_admin_menu() {
    add_menu_page(
        '3P Patrimônio - Leads',
        '3P Patrimônio',
        'manage_options',
        'p3-leads-manager',
        'p3_render_crm_page',
        'dashicons-chart-line',
        30
    );
}

// Handler de exportação CSV para os sócios
add_action('admin_init', 'p3_handle_export_csv');
function p3_handle_export_csv() {
    if (isset($_GET['page']) && $_GET['page'] === 'p3-leads-manager' && isset($_GET['action']) && $_GET['action'] === 'export_csv') {
        if (!current_user_can('manage_options')) {
            wp_die('Acesso negado.');
        }

        global $wpdb;
        $table_name = $wpdb->prefix . 'p3_leads';
        $leads = $wpdb->get_results("SELECT * FROM $table_name ORDER BY id DESC");

        header('Content-Type: text/csv; charset=utf-8');
        header('Content-Disposition: attachment; filename=3p_patrimonio_leads_' . date('Y-m-d_His') . '.csv');
        header('Pragma: no-cache');
        header('Expires: 0');

        $output = fopen('php://output', 'w');
        // Adiciona BOM para UTF-8 no Excel
        fprintf($output, chr(0xEF).chr(0xBB).chr(0xBF));
        fputcsv($output, array('ID', 'Data/Hora', 'Nome', 'WhatsApp', 'E-mail', 'Objetivo', 'Credito Pretendido', 'Parcela Estimada', 'Status', 'Mensagem', 'Notas'));

        if (!empty($leads)) {
            foreach ($leads as $l) {
                fputcsv($output, array(
                    $l->id,
                    $l->created_at,
                    $l->name,
                    $l->whatsapp,
                    $l->email,
                    $l->objective,
                    $l->credit_amount,
                    $l->monthly_installment,
                    $l->status,
                    $l->message,
                    $l->notes ?? ''
                ));
            }
        }
        fclose($output);
        exit;
    }
}

function p3_render_crm_page() {
    global $wpdb;
    $table_name = $wpdb->prefix . 'p3_leads';
    p3_create_leads_table();
    $leads = $wpdb->get_results("SELECT * FROM $table_name ORDER BY id DESC");
    $total = is_array($leads) ? count($leads) : 0;
    $export_url = admin_url('admin.php?page=p3-leads-manager&action=export_csv');
    
    echo '<div class="wrap" style="font-family: -apple-system, BlinkMacSystemFont, sans-serif;">';
    echo '<div style="background: #020617; padding: 24px; border-radius: 16px; margin-bottom: 24px; border: 1px solid #1e293b; color: #fff;">';
    echo '<div style="display: flex; align-items: center; justify-content: space-between; flex-wrap: wrap; gap: 16px;">';
    echo '<div>';
    echo '<span style="background: rgba(245, 158, 11, 0.2); color: #fbbf24; border: 1px solid rgba(245, 158, 11, 0.4); padding: 4px 10px; border-radius: 9999px; font-size: 11px; font-weight: bold; text-transform: uppercase;">Módulo CRM dos Sócios</span>';
    echo '<h1 style="color: #f8fafc; font-size: 24px; font-weight: 800; margin: 8px 0 4px 0;">🏛️ Painel de Movimentação dos Sócios - 3P Patrimônio</h1>';
    echo '<p style="color: #94a3b8; margin: 0; font-size: 13px;">Hospedado na Hostinger • Banco MySQL • Total de Leads: <strong style="color: #fbbf24;">' . $total . '</strong></p>';
    echo '</div>';
    echo '<div style="display: flex; gap: 12px; align-items: center;">';
    echo '<a href="' . esc_url($export_url) . '" style="background: #1e293b; color: #f8fafc; border: 1px solid #334155; font-weight: 600; padding: 10px 16px; border-radius: 10px; text-decoration: none; font-size: 13px;">📥 Exportar Planilha CSV</a>';
    echo '<a href="https://wa.me/5511996876748" target="_blank" style="background: #f59e0b; color: #020617; font-weight: bold; padding: 10px 18px; border-radius: 10px; text-decoration: none; font-size: 13px;">WhatsApp Consultoria &rarr;</a>';
    echo '</div>';
    echo '</div>';
    echo '</div>';

    echo '<table class="wp-list-table widefat fixed striped" style="border-radius: 12px; overflow: hidden; border: 1px solid #cbd5e1;">';
    echo '<thead><tr style="background: #f1f5f9;">';
    echo '<th style="font-weight: 700;">Data</th>';
    echo '<th style="font-weight: 700;">Nome</th>';
    echo '<th style="font-weight: 700;">WhatsApp</th>';
    echo '<th style="font-weight: 700;">Objetivo</th>';
    echo '<th style="font-weight: 700;">Crédito</th>';
    echo '<th style="font-weight: 700;">Parcela</th>';
    echo '<th style="font-weight: 700;">Status</th>';
    echo '</tr></thead>';
    echo '<tbody>';

    if ($total > 0) {
        foreach ($leads as $l) {
            $whats_clean = preg_replace('/[^0-9]/', '', $l->whatsapp);
            echo '<tr>';
            echo '<td><small style="color:#64748b;">' . esc_html($l->created_at) . '</small></td>';
            echo '<td><strong>' . esc_html($l->name) . '</strong></td>';
            echo '<td><a href="https://wa.me/' . esc_attr($whats_clean) . '" target="_blank" style="color: #059669; font-weight: 600; text-decoration: none;">📱 ' . esc_html($l->whatsapp) . '</a></td>';
            echo '<td>' . esc_html($l->objective) . '</td>';
            echo '<td><strong style="color: #0284c7;">' . esc_html($l->credit_amount) . '</strong></td>';
            echo '<td>' . esc_html($l->monthly_installment ?? '-') . '</td>';
            echo '<td><span style="background: #fef3c7; color: #92400e; padding: 4px 10px; border-radius: 9999px; font-weight: bold; font-size: 11px;">' . esc_html($l->status) . '</span></td>';
            echo '</tr>';
        }
    } else {
        echo '<tr><td colspan="7" style="text-align: center; padding: 40px; color: #64748b;">Nenhum lead capturado ainda. Os novos contatos cadastrados no site aparecerão aqui automaticamente.</td></tr>';
    }

    echo '</tbody></table>';
    echo '</div>';
}

// 3. Endpoint REST API nativo para Webhooks de Leads e Instagram Ads no WP Hostinger
add_action('rest_api_init', function () {
    register_rest_route('p3/v1', '/lead', array(
        'methods'             => array('POST', 'OPTIONS'),
        'callback'            => 'wp_p3_handle_lead_webhook',
        'permission_callback' => '__return_true'
    ));

    register_rest_route('p3/v1', '/instagram-lead', array(
        'methods'             => array('POST', 'OPTIONS'),
        'callback'            => 'wp_p3_handle_lead_webhook',
        'permission_callback' => '__return_true'
    ));
});

// Suporte a CORS para Hostinger no Plugin
add_action('rest_api_init', function() {
    remove_filter('rest_pre_serve_request', 'rest_send_cors_headers');
    add_filter('rest_pre_serve_request', function($value) {
        header('Access-Control-Allow-Origin: *');
        header('Access-Control-Allow-Methods: POST, GET, OPTIONS, PUT, DELETE');
        header('Access-Control-Allow-Headers: Authorization, Content-Type, X-WP-Nonce, X-Requested-With');
        return $value;
    });
}, 15);

function wp_p3_handle_lead_webhook($request) {
    global $wpdb;
    nocache_headers();
    $table = $wpdb->prefix . 'p3_leads';
    $params = $request->get_json_params();

    if (empty($params)) {
        $params = $request->get_params();
    }
    
    $name     = sanitize_text_field($params['name'] ?? 'Lead Sem Nome');
    $whatsapp = sanitize_text_field($params['whatsapp'] ?? '');
    $email    = sanitize_email(trim($params['email'] ?? ''));
    $obj      = sanitize_text_field($params['objective'] ?? 'Consórcio');
    $credit   = sanitize_text_field($params['creditAmount'] ?? ($params['credit_amount'] ?? 'A definir'));
    $parcel   = sanitize_text_field($params['monthlyInstallment'] ?? ($params['monthly_installment'] ?? ''));
    $msg      = sanitize_textarea_field($params['message'] ?? 'Cadastrado via formulário / webhook 3P');

    if (empty($whatsapp)) {
        return new WP_REST_Response(array('success' => false, 'error' => 'WhatsApp obrigatório'), 400);
    }

    $is_ebook = ($obj === 'Download de E-book Patrimonial' || ($params['utmSource'] ?? '') === 'ebook_download');
    if ($is_ebook && (empty($email) || !is_email($email))) {
        return new WP_REST_Response(array('success' => false, 'error' => 'Por favor, informe um endereço de e-mail válido para receber o e-book.'), 400);
    }

    if (!empty($email) && !is_email($email)) {
        return new WP_REST_Response(array('success' => false, 'error' => 'Formato de e-mail inválido.'), 400);
    }

    // Bloqueio de e-mails descartáveis
    if (!empty($email)) {
        $email_parts = explode('@', $email);
        $domain = end($email_parts);
        $disposable = array('mailinator.com', 'tempmail.com', '10minutemail.com', 'guerrillamail.com', 'throwawaymail.com', 'yopmail.com', 'sharklasers.com');
        if (in_array(strtolower($domain), $disposable, true)) {
            return new WP_REST_Response(array('success' => false, 'error' => 'Provedores de e-mail temporários não são permitidos para receber o e-book.'), 400);
        }
    }

    $inserted = $wpdb->insert($table, array(
        'created_at'          => current_time('mysql'),
        'name'                => $name,
        'whatsapp'            => $whatsapp,
        'email'               => $email,
        'objective'           => $obj,
        'credit_amount'       => $credit,
        'monthly_installment' => $parcel,
        'message'             => $msg,
        'status'              => 'Novo'
    ));

    if ($inserted === false) {
        return new WP_REST_Response(array('success' => false, 'error' => $wpdb->last_error), 500);
    }

    if ($is_ebook && !empty($email) && function_exists('wp_mail')) {
        $subject = "Seu E-book 3P Patrimônio: Como Construir Patrimônio Utilizando Consórcios";
        $home = home_url('/#ebook');
        $body_mail = "Olá, {$name}!\n\nSeu exemplar exclusivo do e-book oficial 'Como Construir Patrimônio Utilizando Consórcios', de autoria de Carlos Yoshimori, foi liberado com sucesso.\n\nVocê pode acessá-lo e fazer o download do PDF completo no link:\n{$home}\n\nFicamos à disposição para tirar dúvidas e apresentar simulações patrimoniais personalizadas.\n\nAtenciosamente,\nCarlos Yoshimori & Equipe 3P Patrimônio\nWhatsApp: (11) 99687-6748";
        @wp_mail($email, $subject, $body_mail);
    }

    return new WP_REST_Response(array('success' => true, 'message' => 'Lead salvo com sucesso no MySQL!'), 200);
}

// Shortcodes para o Elementor (compatível com qualquer tema)
if (!shortcode_exists('p3_whatsapp')) {
    add_shortcode('p3_whatsapp', function ($atts) {
        $a = shortcode_atts(array(
            'phone'   => '5511996876748',
            'text'    => 'Falar com Carlos Yoshimori no WhatsApp',
            'message' => 'Olá Carlos Yoshimori, conheci o 3P Patrimônio e gostaria de conversar sobre estratégia de consórcio.'
        ), $atts);

        $url = 'https://wa.me/' . preg_replace('/[^0-9]/', '', $a['phone']) . '?text=' . rawurlencode($a['message']);
        
        return '<a href="' . esc_url($url) . '" target="_blank" rel="noopener noreferrer" style="display: inline-flex; align-items: center; justify-content: center; gap: 8px; background: #f59e0b; color: #020617; font-weight: 800; font-size: 14px; text-transform: uppercase; letter-spacing: 0.05em; padding: 14px 28px; border-radius: 12px; text-decoration: none; box-shadow: 0 10px 25px -5px rgba(245, 158, 11, 0.3); transition: all 0.2s ease;">
            <span style="font-size: 18px;">📱</span> ' . esc_html($a['text']) . ' &rarr;
        </a>';
    });
}

if (!shortcode_exists('p3_app')) {
    add_shortcode('p3_app', function () {
        return '<div id="p3-elementor-app-container" class="w-full"><div id="root"></div></div>';
    });
}

